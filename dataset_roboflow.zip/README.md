# Pokemon Card Dataset
        
Generated on 2025-11-08 14:00:39

## Split
- Train: 0 images
- Valid: 0 images

## Usage
This dataset is ready to use with YOLOv8:
```python
from ultralytics import YOLO
model = YOLO('yolov8n.pt')
results = model.train(data='data.yaml', epochs=100)
```
